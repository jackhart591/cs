To compile: gcc assign1.c assign2.c -o movies_by_year
