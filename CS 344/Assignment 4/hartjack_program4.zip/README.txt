to compile: gcc assign4.c -pthread -o myCounter
