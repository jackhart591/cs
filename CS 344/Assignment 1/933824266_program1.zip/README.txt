TO COMPILE:

gcc assign1.c -o movies