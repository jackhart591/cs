To compile: type "compile"
